﻿using System;using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your name ");
           string name =  Console.ReadLine();
            Console.WriteLine("Please enter your age");
            int age;
            if (int.TryParse(Console.ReadLine(), out age)) 
            { }
            else
            {
                Console.WriteLine("Parsing eror");
            }

            string msg = string.Format("{0}, {1} {0}", age, name);
            string msg1 = "{age}, {name}";
            Console.WriteLine(msg);
            Console.WriteLine(msg1);
            Console.WriteLine("{0}, {1}", age, name);
            msg = msg + msg1;
            

            string message = age > 18? $"Hello {name}" :
                "Sorry jfkjfjbvf";
            Console.WriteLine(message);

            // if (age < 18)
            // { Console.WriteLine("Sorry jfkjfjbvf");
            //   }
            //   else
            //   {
            //  Console.WriteLine("you can vote");
            // }
                  Console.ReadLine();


        }
    }
}
